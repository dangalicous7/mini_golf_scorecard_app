package com.example.minigolf

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.core.os.bundleOf
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.hw_2.Model
import java.io.OutputStreamWriter


class RecentGames : Fragment() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var viewAdapter: RecyclerView.Adapter<*>
    private var gameItems = ArrayList<GameObject>()
    private lateinit var viewModel: Model


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        //gets view model
        viewModel = ViewModelProvider(requireActivity())[Model::class.java]

        //gets data set for recycler view
        //Log.i("Recent Games", viewModel.getGameArray()[0].getTitle())

        gameItems = viewModel.getGameArray()

        Log.i("Recent Games Array", gameItems.toString())

        //inflates fragment
        var view = inflater.inflate(R.layout.fragment_recent_games, container, false)

        //set up recycler view
        recyclerView = view.findViewById(R.id.recentGamesRecyclerView)
        // This tells the recyclerview that we want to show our data items in a vertical list. We could do a horizontal list,
        // a grid or even something custom in order to display the data items.
        recyclerView.layoutManager = LinearLayoutManager(context, RecyclerView.VERTICAL, false)
        viewAdapter = RecyclerViewAdapter(gameItems, activity as MainActivity)
        recyclerView.adapter = viewAdapter

        //clear games button listener
        view.findViewById<Button>(R.id.clearGames).setOnClickListener(){
            //clear games in file
            clearGames()
            //clear array list in view model
            viewModel.resetGameArray()

            //resets the recycler view and adapter
            gameItems = viewModel.getGameArray()
            viewAdapter = RecyclerViewAdapter(gameItems, activity as MainActivity)
            recyclerView.adapter = viewAdapter


        }

        return view
    }


    //function to clear the data set
    fun clearGames(){
        // opens file and replaces content with blank string
        try {

            val fileOut = activity?.openFileOutput("recentGames.txt", Activity.MODE_PRIVATE)
            val outputWriter = OutputStreamWriter(fileOut)
            outputWriter.write("")
            outputWriter.close()


        } catch (e: Exception) {
            e.printStackTrace()
        }
    }



    class RecyclerViewAdapter(private val myDataset: ArrayList<GameObject>, private val activity: MainActivity) :
        RecyclerView.Adapter<RecyclerViewAdapter.ViewHolder>() {
        override fun onCreateViewHolder(parent: ViewGroup,
                                        viewType: Int): RecyclerViewAdapter.ViewHolder {
            val v = LayoutInflater.from(parent.context)
                .inflate(R.layout.recentgamesrecyclerviewitem, parent, false)

            return ViewHolder(v, activity)
        }
        override fun onBindViewHolder(holder: ViewHolder, position: Int) {

            holder.bindItems(myDataset[position], (position % 2))
        }

        // Return the size of your dataset (invoked by the layout manager)
        override fun getItemCount() = myDataset.size

        class ViewHolder(private val view: View, private val activity: MainActivity) : RecyclerView.ViewHolder(view){


            //sets text and background color for recycler view items
            fun bindItems(gameItem: GameObject, backgroundColor: Int) {
                val title: TextView = itemView.findViewById(R.id.rectitle)

                title.text = gameItem.getTitle()

                if(backgroundColor == 0)
                    itemView.setBackgroundColor(Color.parseColor("#e0e0e0"))
                else
                    itemView.setBackgroundColor(Color.parseColor("#cfcfcf"))
                val args = Bundle()
                args.putString("title", gameItem.getTitle())

                itemView.setOnClickListener {
                    //passes the title of the game to be used in the detail fragment
                    view.findNavController().navigate(R.id.action_recentGames_to_gameDetails, args)

                }
            }
        }
    }

}