package com.example.minigolf

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.NavController
import androidx.navigation.Navigation
import com.example.hw_2.Model
import java.io.InputStreamReader


class MenuFragment : Fragment() {

    private lateinit var viewModel: Model
    var navc: NavController? = null
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        //reads data from file and stores in in arraylist in viewmodel
        readFile()

        //gets viewModel
        viewModel = ViewModelProvider(requireActivity())[Model::class.java]

        navc = Navigation.findNavController(view)
        view.findViewById<Button>(R.id.startGame).setOnClickListener {
            navc!!.navigate(R.id.action_menuFragment_to_createGame)
            //sets current game
            viewModel.setCurrGame(GameObject("No Title" + viewModel.getGameArray().size.toString(), 0, ArrayList<Player>(), 0.0, 0.0, ""))
        }
        view.findViewById<Button>(R.id.recentGames).setOnClickListener {
            navc!!.navigate(R.id.action_menuFragment_to_recentGames)
        }
    }

    fun readFile(){

        val READ_BLOCK_SIZE = 100
        viewModel = ViewModelProvider(requireActivity())[Model::class.java]

        //reset the arraylist so data doesn't double
        viewModel.resetGameArray()

        //reading text from file
        try {
            val fileIn = activity?.openFileInput("recentGames.txt")

            val InputRead = InputStreamReader(fileIn)
            val inputBuffer = CharArray(READ_BLOCK_SIZE)
            var s: String? = ""
            var charRead: Int
            while (InputRead.read(inputBuffer).also { charRead = it } > 0) {
                // char to string conversion
                val readstring = String(inputBuffer, 0, charRead)
                s += readstring
            }
            InputRead.close()

            //gets array of parts from big string
            var parts = s?.split(";")
            Log.i("Menuuu2", parts.toString())
            var game = GameObject("~no game here",100, ArrayList<Player>(), 2.1,2.1, "~no address")

            //loops through all the parts in the string delimited by a ","
            for(i in 0..parts!!.size -1){
                //checks if its at a title of a new game ))
                if(parts[i].length > 0 && parts[i].get(0).equals('~')){
                    if(!game.getTitle().equals("~no game here")){
                        //adds game to array in view model if its a new game and if it
                        //has to add here before it starts making a new game
                       viewModel.getGameArray().add(game)
                    }
                    Log.i("Menuuu2",parts[0])
                    //makes new game
                    game = GameObject(parts[i].drop(1),parts[i+1].toInt(), makePlayers(parts[i+5]), parts[i+3].toDouble(), parts[i+2].toDouble(), parts[i+4].drop(1))

                }
            }
            //adds game to viewmodel list
            if(!game.getTitle().equals("~no game here")) {
                viewModel.getGameArray().add(game)
            }

            Log.i("Menuuuu", viewModel.getGameArray().toString())

        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    //this function takes the string containing all the players scores and makes it
    //int an array of player objects to be added to the game
    fun makePlayers(str: String): ArrayList<Player> {
        var array = ArrayList<Player>()
        //takes off the first - on the string passed in
        var parts = str.drop(1).split("-")
        //Log.i("makePlayers" ,"making players out of " + str)

        //loops through dilimited parts
        for(i in 0 .. parts.size-1){
            var arr = ArrayList<Int>()
            //Log.i("makePlayers" ,i.toString() + "-"+parts[i].removeSurrounding("","\n").toInt()+"-")

            //adds total score as score of first hole to array of scores
            //removes \n at the end of the last int
            arr.add(parts[i].removeSurrounding("","\n").toInt())
            //Log.i("makePlayers" ,arr.size.toString())

            //creates new player and adds it to the player array
            array.add(Player("Player " + (i+1).toString(), arr))
        }
        //Log.i("makePlayers" ,array[0].getScores().toString())

        return array
    }
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_menu, container, false)
    }
}
