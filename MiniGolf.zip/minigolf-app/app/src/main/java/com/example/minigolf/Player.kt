package com.example.minigolf

class Player(val name: String?, private val scores: ArrayList<Int>) {

    // Method to calculate the total score
    fun getTotalScore(): Int {
        var totalScore = 0
        for (score in scores) {
            totalScore += score
        }
        return totalScore
    }

    // Method to get the scores for each hole
    fun getScores(): ArrayList<Int> {
        return scores
    }

}