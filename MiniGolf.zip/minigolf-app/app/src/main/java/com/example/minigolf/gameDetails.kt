package com.example.minigolf

import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.NavController
import androidx.navigation.Navigation
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.hw_2.Model
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.MapView
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions


class gameDetails : Fragment(), OnMapReadyCallback {

    //initializes viewModel
    private lateinit var viewModel: Model

    var navc: NavController? = null
    private lateinit var recyclerView: RecyclerView
    private lateinit var viewAdapter: RecyclerView.Adapter<*>
    val position = LatLng(-33.920455, 18.466941)
    var mapView: MapView? = null
    var gMap: GoogleMap? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View? {

        //get viewModel
        viewModel = ViewModelProvider(requireActivity())[Model::class.java]

        //gets title of game to display
        var title: String? = requireArguments().getString("title")
        viewModel.setSelectedGame(title!!)

        // Inflate the layout for this fragment
        var view = inflater.inflate(R.layout.fragment_game_details, container, false)

        //sets the title of the fragment to the game title
        view.findViewById<TextView>(R.id.gameTitle).text = viewModel.getSelectedGame().getTitle()

        Log.i("GameDetails", viewModel.getGameArray()[0].toStringFile())


        //sets the winner text
        view.findViewById<TextView>(R.id.winnerTitle).text = "Winner: " + viewModel.getSelectedGame().determineWinner()

        view.findViewById<TextView>(R.id.address).text = viewModel.getSelectedGame().getAddress()

        recyclerView = view.findViewById(R.id.finalScoresRecyclerView)
        // This tells the recyclerview that we want to show our data items in a vertical list. We could do a horizontal list,
        // a grid or even something custom in order to display the data items.
        recyclerView.layoutManager = LinearLayoutManager(context, RecyclerView.VERTICAL, false)

        //gets player list
        val playerList = viewModel.getSelectedGame().getPlayers()

        viewAdapter = PlayerAdapter(playerList)

        recyclerView.adapter = viewAdapter

        mapView = view.findViewById(R.id.mapView)
        mapView?.onCreate(savedInstanceState)
        mapView?.onResume()

        mapView?.getMapAsync(this)
        return view

    }

    override fun onResume() {
        super.onResume()
        mapView?.onResume()
    }

    override fun onPause() {
        super.onPause()
        mapView?.onPause()
    }

    override fun onDestroy() {
        super.onDestroy()
        mapView?.onDestroy()
    }

    override fun onLowMemory() {
        super.onLowMemory()
        mapView?.onLowMemory()
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        //menu button
        navc = Navigation.findNavController(view)
        view.findViewById<Button>(R.id.menu).setOnClickListener {
            navc!!.navigate(R.id.action_gameDetails_to_menuFragment)
        }
        //overrides back button so it also goes back to menu
        activity?.onBackPressedDispatcher?.addCallback(viewLifecycleOwner, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {

                navc!!.navigate(R.id.action_gameDetails_to_menuFragment)

            }
        })
    }


    // Adapter for RecyclerView
    inner class PlayerAdapter(private val players: ArrayList<Player>) : RecyclerView.Adapter<PlayerAdapter.PlayerViewHolder>() {

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PlayerViewHolder {
            val view = LayoutInflater.from(parent.context).inflate(R.layout.scoreboardrecyclerviewitem, parent, false)
            return PlayerViewHolder(view)
        }

        override fun onBindViewHolder(holder: PlayerViewHolder, position: Int) {

            holder.bind(players[position], (position % 2))
        }

        override fun getItemCount(): Int {
            return players.size
        }

        inner class PlayerViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

            private val playerName: TextView = itemView.findViewById(R.id.playerNameTextView)
            private val strokes: TextView = itemView.findViewById(R.id.playerScoreTextView)

            //sets text and background color of each recycler view item
            fun bind(player: Player, backgroundColor: Int) {
                playerName.text = player.name
                strokes.text = player.getTotalScore().toString()
                if(backgroundColor == 0)
                    itemView.setBackgroundColor(Color.parseColor("#e0e0e0"))
                else
                    itemView.setBackgroundColor(Color.parseColor("#cfcfcf"))
            }
        }
    }

    override fun onMapReady(googleMap: GoogleMap) {
        gMap = googleMap
        val latlng = LatLng(viewModel.getCurrGame().getLat(), viewModel.getCurrGame().getLong())
        val zoomLevel = 10f
        gMap?.animateCamera(CameraUpdateFactory.newLatLng(latlng))
        gMap?.animateCamera(CameraUpdateFactory.newLatLngZoom(latlng, zoomLevel))
        gMap?.addMarker(
            MarkerOptions()
                .position(latlng)
                .title("Golf course")
        )

    }


}
