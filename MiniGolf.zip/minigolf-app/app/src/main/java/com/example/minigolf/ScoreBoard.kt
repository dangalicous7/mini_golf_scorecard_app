package com.example.minigolf

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.NavController
import androidx.navigation.Navigation
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.hw_2.Model
import java.io.OutputStreamWriter

class ScoreBoard : Fragment() {
    //initializes viewModel
    private lateinit var viewModel: Model

    private lateinit var numStrokes: TextView
    private lateinit var strokesPlus: Button
    private lateinit var strokesMinus: Button
    private lateinit var spinnerPlayer: Spinner
    private lateinit var spinnerHole: Spinner
    private lateinit var updateScoreBtn: Button
    private var nav: NavController? = null

    // Variables to hold player and hole information
    private var selectedPlayer: String? = null
    private var selectedHole: Int = 1
    private var numberOfStrokes: Int = 0


    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_score_board, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        viewModel = ViewModelProvider(requireActivity())[Model::class.java]

        // Declare and initialize playerList as an ArrayList of Player data class
        val playerList = viewModel.getCurrGame().getPlayers()

        // Declare and initialize playerAdapter as a RecyclerView adapter
        var playerAdapter = PlayerAdapter(playerList)

        // Declare and initialize playerRecyclerView as a RecyclerView view
        lateinit var playerRecyclerView: RecyclerView

        //gets views
        numStrokes = view.findViewById(R.id.textView5)
        strokesPlus = view.findViewById(R.id.button2)
        strokesMinus = view.findViewById(R.id.button)
        spinnerPlayer = view.findViewById(R.id.spinner2)
        spinnerHole = view.findViewById(R.id.spinner3)
        updateScoreBtn = view.findViewById(R.id.button3)

        // Initialize playerRecyclerView with the appropriate RecyclerView view from layout XML
        playerRecyclerView = view.findViewById(R.id.recyclerView)

        // Set the adapter to playerRecyclerView
        playerRecyclerView.adapter = playerAdapter

        // Set up spinner for player selection
       val players = ArrayList<String>()
       for(player in playerList){
           players.add(player.name!!)
       }

        //sets up player spinner
        spinnerPlayer.adapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_dropdown_item, players)
        spinnerPlayer.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                //gets player name of item selected
                selectedPlayer = players[position]

                //autofill textfield with players current hole score
                var playerIndex = 0
                for(i in 0..playerList.size-1){
                    if(playerList.get(i).name.equals(selectedPlayer)){
                        playerIndex = i
                    }
                }
                numberOfStrokes = viewModel.getCurrGame().getScore(playerIndex,selectedHole)
                numStrokes.text = numberOfStrokes.toString()            }

            override fun onNothingSelected(parent: AdapterView<*>?) {
                // Do nothing
            }
        }

        // Set up spinner for hole selection
        val holeCount = viewModel.getCurrGame().getHoles()
        val holes = ArrayList<String>()
        for(i in 1 .. holeCount!!){
            holes.add(i.toString())
        }

        spinnerHole.adapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_dropdown_item, holes)
        spinnerHole.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                //gets the integer value of the hole choosen
                selectedHole = holes[position].toInt()

                //autofill textfield with players current hole score
                var playerIndex = 0
                for(i in 0..playerList.size-1){
                    if(playerList.get(i).name.equals(selectedPlayer)){
                        playerIndex = i
                    }
                }

                numberOfStrokes = viewModel.getCurrGame().getScore(playerIndex,selectedHole)
                numStrokes.text = numberOfStrokes.toString()
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {
                // Do nothing
            }
        }

        //updates stroke count
        strokesPlus.setOnClickListener {
            numberOfStrokes++
            numStrokes.text = numberOfStrokes.toString()
        }
        //updates stroke count
        strokesMinus.setOnClickListener {
            if (numberOfStrokes > 0) {
                numberOfStrokes--
                numStrokes.text = numberOfStrokes.toString()
            }
        }
        //posts the values to the current game
        updateScoreBtn.setOnClickListener {

            //searches through viewmodels player list and finds correct player
            //updates playerIndex so we make changes to the right player
            var playerIndex = 0
            for(i in 0..playerList.size-1){
                if(playerList.get(i).name.equals(selectedPlayer)){
                    playerIndex = i
                }
            }

            //updates the players score in the right index
            viewModel.getCurrGame().updateScore(playerIndex,selectedHole, numberOfStrokes)

            playerAdapter.notifyDataSetChanged()
        }

        // Set up RecyclerView
        playerAdapter = PlayerAdapter(playerList)
        playerRecyclerView.layoutManager = LinearLayoutManager(requireContext())
        playerRecyclerView.adapter = playerAdapter

        nav = Navigation.findNavController(view)


        //end game button
        view.findViewById<Button>(R.id.button4).setOnClickListener {
            //adds current game to array of games to be printed to file
            viewModel.addGame()

            //writes data to file
            writeFile()
            val args = Bundle()
            args.putString("title", viewModel.getCurrGame().getTitle())

            //navigates to next fragment
            nav?.navigate(R.id.action_scoreBoard_to_gameDetails, args)

        }

    }

    fun writeFile(){

        // write game data into a file
        try {

            val fileOut = activity?.openFileOutput("recentGames.txt", Activity.MODE_PRIVATE)


            val outputWriter = OutputStreamWriter(fileOut)
            //Toast.makeText(activity, viewModel.generateFile(), Toast.LENGTH_SHORT).show()
            outputWriter.write(viewModel.generateFile())

            outputWriter.close()


        } catch (e: Exception) {
            e.printStackTrace()
        }

    }

    // Adapter for RecyclerView
    inner class PlayerAdapter(private val players: ArrayList<Player>) : RecyclerView.Adapter<PlayerAdapter.PlayerViewHolder>() {

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PlayerViewHolder {
            val view = LayoutInflater.from(parent.context).inflate(R.layout.scoreboardrecyclerviewitem, parent, false)
            return PlayerViewHolder(view)
        }

        override fun onBindViewHolder(holder: PlayerViewHolder, position: Int) {

            holder.bind(players[position], (position % 2))
        }

        override fun getItemCount(): Int {
            return players.size
        }

        inner class PlayerViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

            private val playerName: TextView = itemView.findViewById(R.id.playerNameTextView)
            private val strokes: TextView = itemView.findViewById(R.id.playerScoreTextView)
            //sets text and background color of recycler view items
            fun bind(player: Player, backgroundColor: Int) {
                playerName.text = player.name
                strokes.text = player.getTotalScore().toString()
                if(backgroundColor == 0)
                    itemView.setBackgroundColor(Color.parseColor("#e0e0e0"))
                else
                    itemView.setBackgroundColor(Color.parseColor("#cfcfcf"))
            }
        }
    }
}


