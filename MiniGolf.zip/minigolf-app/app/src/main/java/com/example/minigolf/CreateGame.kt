package com.example.minigolf

import android.annotation.SuppressLint
import android.content.Context
import android.location.Address
import android.location.Geocoder
import android.location.Location
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.NavController
import androidx.navigation.Navigation
import com.example.hw_2.Model
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import java.util.*


class CreateGame : Fragment() {

    //initializes controller and view model
    var navc: NavController? = null
    private lateinit var viewModel: Model
    //A connection to the Google Play location API
    private lateinit var fusedLocationClient: FusedLocationProviderClient
    //Geocoder will handling the andress lookup
    lateinit var  geocoder : Geocoder
    //this will be used to pass the current coordinates to Geocoder
    var latlong: Location? = null


    @SuppressLint("MissingPermission")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        //gets viewModel
        viewModel = ViewModelProvider(requireActivity())[Model::class.java]

        //Geocoder will handling the andress lookup
        geocoder = Geocoder(activity as Context, Locale.getDefault())

        //declares variables
        var players = 0
        var holes = 0
        var validTitle = false

        //function is called every time player count is updated
        //it makes sure number doesnt get below 1 and updates the textview and viewmodel
        fun updatePlayers(playerNum: Int){
            //makes sure you can't enter number less than 1
            if(playerNum < 1) {
                players = 1
            } else {
                players = playerNum
            }
            //updates textview
            view.findViewById<TextView>(R.id.numPlayersText).text = players.toString()

            //updates current game in view model
            //viewModel.getCurrentGame().value?.setPlayers(players)
            viewModel.getCurrGame().setPlayers(players)

            //Toast.makeText(activity, viewModel.getCurrentGame().value?.getPlayers()?.size.toString(), Toast.LENGTH_SHORT).show()
        }

        //function to update number of holes
        //cant be less than 1 and also updates the textview and viewModel
        fun updateHoles(holesNum: Int){
            //makes sure you can't enter number less than 1
            if(holesNum < 1) {
                holes = 1
            } else {
                holes = holesNum
            }
            //updates textview
            view.findViewById<TextView>(R.id.numHolesText).text = holes.toString()

            //updates current game in view model
            viewModel.getCurrGame().setHoles(holes)
        }

        //sets initial values
        updatePlayers(1)
        updateHoles(18)


        //plus minus buttons for players
        view.findViewById<Button>(R.id.playersPlus).setOnClickListener {
            updatePlayers(players+1)
        }
        view.findViewById<Button>(R.id.playersMinus).setOnClickListener {
            updatePlayers(players-1)
        }

        //plus minus buttons for holes
        view.findViewById<Button>(R.id.holesPlus).setOnClickListener {
            updateHoles(holes+1)
        }

        view.findViewById<Button>(R.id.holesMinus2).setOnClickListener {
            updateHoles(holes-1)
        }

        //sets text box string to game title
        view.findViewById<EditText>(R.id.editText).addTextChangedListener(object : TextWatcher {

            override fun afterTextChanged(s: Editable) {}

            override fun beforeTextChanged(s: CharSequence, start: Int,
                                           count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence, start: Int,
                                       before: Int, count: Int) {

                var title = s.toString()

                //checks if new text is a blank space, empty string, or a duplicate of a current title
                if(title.equals(" ") || title.equals("") || !checkTitle(title) || title.contains(';')){
                    validTitle = false
                } else {
                    validTitle = true
                    //sets current games title
                    viewModel.getCurrGame().setTitle(s.toString())
                }




            }
            //loops through finished games and makes sure title can't be the exact same
            fun checkTitle( str : String): Boolean{
                var valid = true
                for(game in viewModel.getGameArray()){
                    if(game.getTitle().equals(str)){
                        valid = false
                    }
                }
                return valid
            }
        })


        //navigates to next fragment
        navc = Navigation.findNavController(view)
        view.findViewById<Button>(R.id.startGame2).setOnClickListener {
            //Create a location client
            fusedLocationClient = LocationServices.getFusedLocationProviderClient(activity as Context)

            //get the last location identified. Also, set a listener that updates the
            //R.id.coordinates text when the location is found (on Success)
            fusedLocationClient.lastLocation
                .addOnSuccessListener { location: Location? ->
                    //we are using the let scope to avoid writing the if statements for this type of assignment
                    location?.let {
                        latlong = it

                        // Got the last known location. In some rare situations this can be null.
                        var addresses = geocoder.getFromLocation(
                            location.latitude,
                            location.longitude,
                            1
                        ) as List<Address>
                        //locks in the location of where the player is when game is created
                        viewModel.getCurrGame().setLocation(addresses.get(0).longitude, addresses.get(0).latitude)
                        viewModel.getCurrGame().setAddress(addresses.get(0).getAddressLine(0))
                    }
                }

            //only navigates if a valid title has been provided
            if(validTitle) {
                updatePlayers(players)
                updateHoles(holes)
                navc!!.navigate(R.id.action_createGame_to_scoreBoard)

            } else {
                Toast.makeText(activity, "Invalid Title... Please try again", Toast.LENGTH_SHORT).show()
            }
        }

    }
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_create_game, container, false)
    }

}