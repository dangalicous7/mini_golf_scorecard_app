package com.example.minigolf

import android.content.Context
import android.location.Geocoder
import android.util.Log
import java.util.*
import kotlin.collections.ArrayList


class GameObject(private var title: String, private var holes: Int, private var players: ArrayList<Player>,
                 private var longitude: Double, private var latitude: Double, private var address: String) {

    fun setTitle(text: String) {
        title = text
    }

    @JvmName("getTitle")
    fun getTitle(): String {
        return title
    }

    fun setHoles(num: Int) {
        holes = num
    }

    @JvmName("getHoles")
    fun getHoles(): Int {
        return holes
    }

    fun addPlayer(person: Player) {
        players.add(person)
    }

    //function that takes a player index, hole number, and stroke count
    //updates that specific players score array
    fun updateScore(playerIndex: Int, hole: Int, strokes: Int){
        players[playerIndex].getScores()[hole-1] = strokes
    }

    fun getScore(playerIndex: Int, hole: Int):Int {
        return players[playerIndex].getScores()[hole-1]
    }

    fun setPlayers(numPlayers: Int){
        //resets array list
        players = ArrayList<Player>()

        Log.i("Testing", holes.toString())
        //recreates arraylist with correct number of players
        for(i in 1..numPlayers){
            val zeroArray = ArrayList<Int>()
            //sets all array values to 0 to start
            for(i in 0 .. holes){
                zeroArray.add(0)
            }

            players.add(Player("Player " + i.toString(),zeroArray))
        }
    }

    fun getPlayers(): ArrayList<Player> {
        //returns array list of players
        return players
    }

    //loops through players to determine which has the smallest score
    fun determineWinner(): String {

        var smallest = players[0]

        for(player in players){
            if(player.getTotalScore() < smallest.getTotalScore()){
                smallest = player
            }
        }

        return smallest.name!!
    }

    //toString function for writing data to a file
    fun toStringFile(): String{

        //adds title, hole count, and lat long to string
        var str = "~" + title + ";" + holes.toString() + ";" + latitude.toString() + ";" + longitude.toString() + ";" + address + ";"
        //adds total scores for each player
        for(player in players){
            str = str + "-" + player.getTotalScore().toString()
        }
        //adds break at end of string and returns
        return str + ";\n;"
    }

    fun setLocation(long: Double, lat: Double){
        longitude = long
        latitude = lat
    }

    fun getLong() : Double {
        //write function to convert lat long to address like in HW5
        return longitude
    }

    fun getLat() : Double {
        return latitude
    }

    fun setAddress(addr : String) {
        address = addr
    }

    fun getAddress() : String {
        return address
    }


}