package com.example.hw_2

import android.util.Log
import androidx.lifecycle.ViewModel
import com.example.minigolf.GameObject
import com.example.minigolf.Player
import kotlin.collections.ArrayList

//View Model holds an array of completed games as well as a current game
class Model : ViewModel() {


    private var currGame: GameObject = GameObject("No Title", 0, ArrayList<Player>(), 0.0, 0.0, "No Address")

    private var gameArray = ArrayList<GameObject>()

    //index of what game is being viewed in game details
    private var selectedGame = 0

    fun getGameArray(): ArrayList<GameObject>{
        return gameArray
    }
    fun resetGameArray(){
        gameArray = ArrayList<GameObject>()
    }
    fun getCurrGame(): GameObject{
        return currGame
    }
    fun setCurrGame(go: GameObject){
        currGame = go
    }

    fun getSelectedGame(): GameObject {
        return gameArray[selectedGame]
    }
    fun setSelectedGame(t: String) {
        //loops through list and finds title
        //if found it sets the index to that game
        for(i in 0..gameArray.size-1){
            if(gameArray[i].getTitle().equals(t)){
                selectedGame = i
            }
        }
    }

    fun addGame(){
        gameArray.add(0,currGame)
        //sets index to where newest game was located
        selectedGame = 0
    }

    //This function returns a string of game items to be written to a file
    fun generateFile(): String {
        var str = ""

        for(game in gameArray){
            str = str + game.toStringFile()
        }
        return str
    }


}



